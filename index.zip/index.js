const express = require('express')

const app = new express()

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/pages/main.html')
})

app.listen(2138, () => {
    console.log('Сервер запустился на http://127.0.0.1:2138/')

})